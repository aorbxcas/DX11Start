#pragma once
#include "ConstantBuffers.h"
#include "../Drawable/Drawable.h"
#include <DirectXMath.h>

namespace Bind
{
	class TransformCbuf : public Bindable
	{
	public:
		TransformCbuf( Graphics& gfx,const Drawable& parent,UINT slot = 0u );
		void Bind( Graphics& gfx ) noexcept override;
	private:
		struct Transforms
		{
			DirectX::XMMATRIX modelViewProj;
			DirectX::XMMATRIX model;
		};
		//VertexConstantBuffer<DirectX::XMMATRIX> vcbuf;
		static std::unique_ptr<VertexConstantBuffer<Transforms>> pVcbuf;
		const Drawable& parent;
	};
}

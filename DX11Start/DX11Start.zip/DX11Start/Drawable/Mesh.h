﻿#pragma once
#include "DrawableBase.h"
#include "../Bindable/BindableCommon.h"
#include "../VertexLayout.h"
#include <assimp/Importer.hpp>
#include <optional>
#include <assimp/scene.h>
#include <assimp/postprocess.h>
#include "../ConditionalNoexcept.h"
#include "../imgui/imgui.h"

class ModelException : public ChiliException
{
public:
    ModelException( int line,const char* file,std::string note ) noexcept;
    const char* what() const noexcept override;
    const char* GetType() const noexcept override;
    const std::string& GetNote() const noexcept;
private:
    std::string note;
};

class Mesh : public DrawableBase<Mesh>
{
public:
    Mesh( Graphics& gfx,std::vector<std::unique_ptr<Bind::Bindable>> bindPtrs );
    void Draw( Graphics& gfx,DirectX::FXMMATRIX accumulatedTransform ) const noxnd;
    DirectX::XMMATRIX GetTransformXM() const noexcept override;
private:
    mutable DirectX::XMFLOAT4X4 transform;
};

class Node
{
    friend class Model;
    friend class ModelWindow;
public:
    Node( const std::string& name,std::vector<Mesh*> meshPtrs,const DirectX::XMMATRIX& transform ) noxnd;
    void Draw( Graphics& gfx,DirectX::FXMMATRIX accumulatedTransform ) const noxnd;
    void SetAppliedTransform( DirectX::FXMMATRIX transform ) noexcept;
private:
    std::string name;
    void RenderTree( int& nodeIndex,std::optional<int>& selectedIndex,Node*& pSelectedNode ) const noexcept;
    void AddChild( std::unique_ptr<Node> pChild ) noxnd;
private:
    std::vector<std::unique_ptr<Node>> childPtrs;
    std::vector<Mesh*> meshPtrs;
    DirectX::XMFLOAT4X4 transform;
    DirectX::XMFLOAT4X4 appliedTransform;
};

class Model
{
public:
    Model( Graphics& gfx,const std::string fileName );
    void Draw( Graphics& gfx) const;
    void ShowWindow( const char* windowName = nullptr ) noexcept;
    ~Model() noexcept;
private:
    static std::unique_ptr<Mesh> ParseMesh( Graphics& gfx,const aiMesh& mesh );
    std::unique_ptr<Node> ParseNode( const aiNode& node ) noexcept;

private:
    std::unique_ptr<Node> pRoot;
    std::vector<std::unique_ptr<Mesh>> meshPtrs;
    struct
    {
        float roll = 0.0f;
        float pitch = 0.0f;
        float yaw = 0.0f;
        float x = 0.0f;
        float y = 0.0f;
        float z = 0.0f;
    } pos;
    std::unique_ptr<class ModelWindow> pWindow;
};